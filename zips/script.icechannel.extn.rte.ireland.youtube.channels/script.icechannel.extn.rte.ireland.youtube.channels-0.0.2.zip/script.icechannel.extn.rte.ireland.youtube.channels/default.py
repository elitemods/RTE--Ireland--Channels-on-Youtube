# default.py
addon_id="script.icechannel.extn.rte.ireland.youtube.channels"
addon_name="RTE (Ireland) Channels on Youtube"
